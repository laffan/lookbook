class Line {

  constructor( ) {

    
  }
}
var fps = 30;
var captureSeconds = 5;
var capturer = new CCapture({ format: 'png', framerate: fps });

function setup() {
  createCanvas(600, 600);
  frameRate(fps);

}

function draw() {

  // captureVideo()

}


function captureVideo() {
  frameCount === 1 && capturer.start();

  if (frameCount === (fps * captureSeconds)) {
    noLoop();
    console.log('finished recording.');
    capturer.stop();
    capturer.save();
    return;
  } else {
    capturer.capture(document.getElementById('defaultCanvas0'));
    let percentComplete = ((frameCount/ fps) / captureSeconds )* 100;
    console.log( `Capture ${percentComplete.toFixed(1) }% complete`)
  };

}